# name="Ivan"
# userName="Ivan"
# user_name="Ivan"
# print(user_name)
# myNumber=input()
# print(myNumber)
# myAge=input("18")
# print("18",myAge)
# isGood=True
# print(isGood)
# myAge = 18
# print("Возраст:", myAge)
# myNumber0ne = 0b11
# myNumberTwo = 0b1011
# myNumberThree = 0b100001
# print(myNumber0ne)
# print(myNumberTwo)
# print(myNumberThree)
import math

a = int(input())
b = int(input())
z1=math.pow((math.cos(a)-math.cos(b)),2)-math.pow(math.sin(a)-math.sin(b),2)
z2=-4*math.pow(math.sin((a-b)/2),2)*math.cos(a+b)
print(z1)
print(z2)